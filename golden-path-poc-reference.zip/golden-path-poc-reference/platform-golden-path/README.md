# platform-golden-path
