# Golden Path POC — Sanitized Work-Side Handoff

## Purpose

This package contains three **personal POC/reference repositories** for architecture review:

- `platform-delivery-lab` — consumer/caller experience
- `platform-workflows` — reusable orchestration
- `platform-golden-path` — contract, normalization/enrichment, governance, and Terraform implementation

These repositories are **not approved company architecture** and are **not authorized for deployment into a work environment** as-is. Their purpose is to provide executable evidence for Golden Path architecture discovery.

## What was sanitized

Before packaging, the handoff copy was cleaned of local repository metadata and personal-environment configuration:

- removed all `.git/` directories and remote metadata/history from the handoff copy;
- removed `.terraform/`, Terraform state/plan files, and `.env`-style files if present;
- removed the personal GitHub/Azure federation JSON and replaced it with `platform-workflows/friday-golden-path-federation.example.json` containing placeholders;
- replaced the personal GitHub owner in source/docs with `YOUR_GITHUB_ORG`;
- removed the personal Terraform backend subscription/resource-group/storage-account values;
- converted Terraform backend configuration to reusable-workflow inputs supplied by GitHub repository/environment variables.

No long-lived Azure client secret is required by the POC. Authentication is designed around GitHub OIDC/federated identity.

## Configuration required before any execution

The consumer workflow now expects these GitHub repository/environment variables:

- `AZURE_SUBSCRIPTION_ID`
- `AZURE_CLIENT_ID`
- `AZURE_TENANT_ID`
- `TF_BACKEND_SUBSCRIPTION_ID`
- `TF_BACKEND_RESOURCE_GROUP`
- `TF_BACKEND_STORAGE_ACCOUNT`
- `TF_BACKEND_CONTAINER`
- `TF_BACKEND_KEY`

The literal `YOUR_GITHUB_ORG` placeholders in reusable-workflow and repository references must be replaced with the organization/repository location selected for any future controlled test. GitHub does not permit arbitrary repository variables in the `uses:` repository reference, so this remains an explicit source/configuration choice rather than a secret.

The example federation file must also be configured for the actual organization, consumer repository, and GitHub environment. Do not copy the example subject blindly into Azure.

## Current technical stopping point

The POC currently demonstrates:

`consumer intent → normalization/enrichment → governance → Azure OIDC → Terraform init/validate/plan`

A controlled invalid input (`environment: banana`) was rejected by governance before Azure authentication or Terraform execution. A valid input (`environment: dev`) passed governance, authenticated using OIDC, and reached a successful Terraform plan.

**The reusable workflow is plan-only. There is no Terraform apply in this handoff.**

That is an intentional architecture boundary. Before adding apply, work-side discovery should establish who owns Terraform execution, Terraform Cloud, runners/workflows, approvals, deployment identities, environment promotion, and CAB/change-management integration. The Golden Path should integrate with an existing organizational execution capability where appropriate rather than inventing a competing one.

## Dish #1

Working definition:

> **Minimal consumer intent → platform-owned enrichment → governance → approved infrastructure handoff.**

`values.yml`/YAML is a POC interface, not a decision that YAML is the final intake experience. Terraform is likewise an implementation mechanism in the POC, not a decision that every future Golden Path outcome must use Terraform.

The architecture may eventually support multiple workload/intake shapes and multiple approved hosting patterns, but this package intentionally proves only a small vertical slice.

## Review posture for Work GPT

Use these repositories to reconstruct the implemented flow, distinguish architecture concepts from POC choices, identify assumptions requiring organizational validation, and locate integration/ownership boundaries.

Do **not** add Terraform apply, additional hosting patterns, a developer portal, Backstage, AKS, Terraform Cloud/OpenTofu changes, CMDB functionality, FinOps tooling, or other platform components merely to make the POC larger.

Before recommending another build, ask:

> **What architectural question would this build answer?**
